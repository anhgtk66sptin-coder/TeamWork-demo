document.getElementById('theme').onclick=()=>document.body.classList.toggle('dark');
document.getElementById('search').addEventListener('input',e=>console.log(e.target.value));