const themeBtn = document.getElementById("themeToggle");
const icon = themeBtn.querySelector("i");

// Đọc giao diện đã lưu
if(localStorage.getItem("theme") === "dark"){

    document.body.classList.add("dark-mode");

    icon.classList.remove("fa-moon");
    icon.classList.add("fa-sun");

}

// Bấm nút đổi giao diện

themeBtn.addEventListener("click",()=>{

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        icon.classList.remove("fa-moon");
        icon.classList.add("fa-sun");

        localStorage.setItem("theme","dark");

    }else{

        icon.classList.remove("fa-sun");
        icon.classList.add("fa-moon");

        localStorage.setItem("theme","light");

    }

});